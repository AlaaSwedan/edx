def exec_(string, globals, locals):
    exec string in globals, locals
