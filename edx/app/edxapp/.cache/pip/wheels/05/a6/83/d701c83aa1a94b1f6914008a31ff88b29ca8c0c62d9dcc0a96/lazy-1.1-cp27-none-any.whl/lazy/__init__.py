"""The lazy module."""

from lazy import lazy
