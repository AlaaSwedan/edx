DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': ':memory:',
    }
}

SECRET_KEY = 'vf7jnp2s-911lr7g$uy5s8-f^h-u_seb38k-4(ww=p1$6r=wu!'
