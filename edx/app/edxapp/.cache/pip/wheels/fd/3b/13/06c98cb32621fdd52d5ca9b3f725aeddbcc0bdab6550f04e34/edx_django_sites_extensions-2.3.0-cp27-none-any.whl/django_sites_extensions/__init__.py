""" django_sites_extensions main module """
default_app_config = 'django_sites_extensions.apps.DjangoSitesExtensionsConfig'  # pragma: no cover
