from dogapi.http import DogHttpApi
from dogapi.stats import DogStatsApi

#FIXME matt: remove the 'dog' variable.
dog = dog_stats_api = DogStatsApi()
dog_http_api = DogHttpApi()
