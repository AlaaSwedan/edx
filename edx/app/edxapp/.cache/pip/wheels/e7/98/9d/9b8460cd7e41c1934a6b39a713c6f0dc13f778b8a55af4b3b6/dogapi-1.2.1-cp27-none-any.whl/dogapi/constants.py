
class MetricType(object):
    Gauge = "gauge"
    Counter = "counter"
    Histogram = "histogram"
