# Use of these from this module will be deprecated.

from ..common.object_wrapper import (in_function, InFunctionWrapper,
        wrap_in_function)
