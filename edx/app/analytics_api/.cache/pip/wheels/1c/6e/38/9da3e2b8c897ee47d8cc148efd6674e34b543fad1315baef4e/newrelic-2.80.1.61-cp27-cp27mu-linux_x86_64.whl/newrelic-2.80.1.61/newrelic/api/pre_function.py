# Use of these from this module will be deprecated.

from ..common.object_wrapper import (pre_function, PreFunctionWrapper,
        wrap_pre_function)
